package Utils;

public class SilentProgress implements Progress
{
    public void done()
    {
        
    }
    
    public void done(int number)
    {
        
    }
}
