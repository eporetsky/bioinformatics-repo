package Utils;

public interface Progress
{
    public void done();
    public void done(int number);
}
